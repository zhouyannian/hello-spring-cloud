package com.zhouyn.demo.servicesecurityoauth2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceSecurityOauth2Application {

    public static void main(String[] args) {
        SpringApplication.run(ServiceSecurityOauth2Application.class, args);
    }

}
